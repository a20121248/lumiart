<script src="<?php echo e(asset('js/admin.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH D:\JAVIER\Documents\Proyectos\lumiart\resources\views/admin/layouts/partials/scripts.blade.php ENDPATH**/ ?>