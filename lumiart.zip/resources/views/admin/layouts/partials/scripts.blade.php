<script src="{{ asset('js/admin.js') }}" defer></script>
@stack('scripts')
