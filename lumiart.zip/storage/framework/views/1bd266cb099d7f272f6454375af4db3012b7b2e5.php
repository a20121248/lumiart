<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH D:\JAVIER\Documents\Proyectos\lumiart\resources\views/app/layouts/partials/scripts.blade.php ENDPATH**/ ?>