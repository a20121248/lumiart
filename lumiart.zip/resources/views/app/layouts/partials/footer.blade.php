<div id="big_footer" class="">
  <div id="primary_footer">
    <div class="footer_newsletter"><div class="mail-box"><div class="mail-news container"><div class="news-l"><div class="opacity-icon"><i class="fa fa-paper-plane-o"></i></div><div class="banner"><h3>Suscríbete a nuestro Newsletter</h3><p>Reciba noticias, actualizaciones interesantes y gratuitas y nuevos productos lanzados (¡sin spam!)</p></div><div class="form">
      <div id="mc_embed_signup">
        <form>
          <div id="mc_embed_signup_scroll">
          <div class="mc-field-group">
          <label for="mce-EMAIL">Correo electrónico</label>
          <input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
          </div>
          <div id="mce-responses" class="clear">
          <div class="response" id="mce-error-response"></div>
          <div class="response" id="mce-success-response"></div>
          </div> 
          <div aria-hidden="true"><input type="text" name="b_19baf45026313d24a55bcf058_3df231ca82" value=""></div>
          <div class="clear"><input type="submit" value="Subscribir" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
          </div>
        </form>
      </div>
      </div></div></div></div>
    </div>
    <div class="container no-fcontainer">
    <div class="footer_sidebar col-xs-12 col-md-4"> <div class="widget widget-contact-info">
    <div class="widget-contact-content centered">
    <i class="fas fa-map-marker"></i>
    <h4 class="widget_title_span">DIRECCIÓN</h4>
    <div class="widget-contact-info-content">PO Box 16122 Collins Street West
    Victoria 8007 Australia</div>
    </div>
    </div>
    </div>
    <div class="footer_sidebar col-xs-12 col-md-4"> <div class="widget widget-contact-info">
    <div class="widget-contact-content centered">
    <i class="fas fa-envelope"></i>
    <h4 class="widget_title_span">EMAIL</h4>
    <div class="widget-contact-info-content"><a href="/cdn-cgi/l/email-protection#442925362f21302d2a2304213c25293428216a272b29"><span class="__cf_email__" data-cfemail="0a676b78616f7e63646d4a6f726b677a666f24696567">lumiart.peru@gmail.com</span></a><br /><br /></div>
    </div>
    </div>
    </div>
    <div class="footer_sidebar col-xs-12 col-md-4"> <div class="widget widget-contact-info">
    <div class="widget-contact-content centered">
    <i class="fas fa-phone"></i>
    <h4 class="widget_title_span">TELÉFONOS</h4>
    <div class="widget-contact-info-content"><a href='tel:+222848333941'>(+222) 848 333 941
    </a><a href='tel:+12484413555'>(+12) 484 413 555</a></div>
    </div>
    </div>
    </div>
    </div>
  </div>
  <div id="secondary_footer">
    <div class="container ">
      <a class="footer_logo align-center" href="http://demos.upperthemes.com/alma/demo1/" tabindex="-1">
        <img class="footer_logo_normal notalone" src="{{ asset('storage/logos/light-2.png') }}" alt="" title="">
        <img class="footer_logo_retina" src="{{ asset('storage/logos/light-2.png') }}" alt="" title="">
      </a>
      <div class="social-icons-fa align-center">
        <ul>
          <li>
            <a href="#" target="_blank" class="social-network facebook" title="Facebook"><i class="fab fa-facebook"></i></a>
          </li>
          <li>
            <a href="#" target="_blank" class="social-network twitter" title="Twitter"><i class="fab fa-twitter"></i></a>
          </li>
          <li>
            <a href="#" target="_blank" class="social-network linkedin" title="LinkedIn"><i class="fab fa-linkedin"></i></a>
          </li>
          <li>
            <a href="#" target="_blank" class="social-network instagram" title="Instagram"><i class="fab fa-instagram"></i></a>
          </li>
          <li>
            <a href="#" target="_blank" class="social-network pinterest" title="Pinterest"><i class="fab fa-pinterest"></i></a>
          </li>
          <li>
            <a href="#" target="_blank" class="social-network dribbble" title="Dribbble"><i class="fab fa-dribbble"></i></a>
          </li>
        </ul>
      </div>
      <div class="footer_custom_text center"><p>Copyright &copy; 2021 <a href="{{ route('home') }}">LumiArt</a>.</strong> Todos los derechos reservados.</p></div>
    </div>
  </div>
</div>