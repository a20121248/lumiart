<footer class="main-footer">
  <div class="float-right d-none d-sm-block">
    <b>Versión</b> 1.0
  </div>
  <strong>Copyright &copy; 2021 <a href="{{ route('home') }}">LumiArt</a>.</strong> Todos los derechos reservados.
</footer>