<script src="{{ asset('js/app.js') }}" defer></script>
@stack('scripts')
